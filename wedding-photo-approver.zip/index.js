// index.js
const { google } = require('googleapis');
const nodemailer = require('nodemailer');
const credentials = require('./credentials.json');
const config = require('./config.json');
const fs = require('fs');

async function notifyUnapprovedPhotos() {
  const auth = new google.auth.GoogleAuth({
    credentials,
    scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly'],
  });

  const sheets = google.sheets({ version: 'v4', auth });

  const res = await sheets.spreadsheets.values.get({
    spreadsheetId: config.sheetId,
    range: config.range,
  });

  const rows = res.data.values;
  if (!rows || rows.length === 0) return;

  const headers = rows[0];
  const nameIndex = headers.indexOf('Name');
  const photoIndex = headers.indexOf('Photo URL');
  const approvalIndex = headers.indexOf('Approved?');

  const unapproved = rows
    .slice(1)
    .filter(row => !row[approvalIndex])
    .map(row => ({
      name: row[nameIndex],
      photo: row[photoIndex],
    }));

  if (unapproved.length > 0) {
    await sendEmail(unapproved);
  }
}

async function sendEmail(photos) {
  const transporter = nodemailer.createTransport(config.email.smtp);

  const content = photos
    .map(p => `<p><strong>${p.name}</strong><br><img src="${p.photo}" width="300"/></p>`)
    .join('');

  await transporter.sendMail({
    from: config.email.from,
    to: config.email.to,
    subject: 'New Wedding Photo Submissions 🎉',
    html: `<h2>You’ve got new photos to approve:</h2>${content}`,
  });

  console.log('✅ Notification sent!');
}

notifyUnapprovedPhotos().catch(console.error);
