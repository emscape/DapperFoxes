# 📸 Wedding Photo Approver

## What It Does
This Node.js script checks your Google Sheet for new, unapproved photo submissions and sends an email with inline previews of the new ones.

## Files
- `index.js`: Main runner script.
- `config.json`: Your custom settings (Sheet ID, email info).
- `credentials.json`: Your Google Service Account key (not included here — you must download this manually).

## Roo Instructions

> “Roo, this is a Node.js script that checks our wedding photo submission sheet for unapproved images and emails me the new ones.
> - Use `index.js` as the runner.
> - Replace the values in `config.json` with our actual SMTP + Google Sheet ID.
> - Add `credentials.json` from our service account.
> - Schedule it to run every 15 minutes on a cron.”

## Manual Step 3 - Service Account Setup (explained below!)
